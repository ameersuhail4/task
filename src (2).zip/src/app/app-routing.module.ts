import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TaskSummaryComponent } from './task-summary/task-summary.component';
import { TaskCompletedComponent } from './task-completed/task-completed.component';
import { TaskPendingComponent } from './task-pending/task-pending.component';
import { TaskListComponent } from './task-list/task-list.component';

const routes: Routes = [
  {path:'task-summary',component:TaskSummaryComponent},
  {path:'task-completed',component:TaskCompletedComponent},
  {path:'task-pending',component:TaskPendingComponent},
  {path:'task-list',component:TaskListComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

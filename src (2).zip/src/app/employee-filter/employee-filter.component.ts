import { Component, OnInit,Input ,Output,EventEmitter} from '@angular/core';


@Component({
  selector: 'app-employee-filter',
  templateUrl: './employee-filter.component.html',
  styleUrls: ['./employee-filter.component.css']
})
export class EmployeeFilterComponent implements OnInit {
  @Output() filterEvent=new EventEmitter<any[]>();
  search:string="";
  filterDept:String="";
  filteredData=[]
  constructor() { }
  @Input() EmployeeList;
  ngOnInit(): void {
    //console.log(this.EmployeeList);
  }
  filterData()
  {
    this.filteredData=this.EmployeeList.filter((employee)=>
    {
      
      if(this.search.length>0 && (this.filterDept.length>0 && this.filterDept!="All"))
      {
        return employee.name.toLowerCase().includes(this.search.toLowerCase()) && employee.department===this.filterDept;
      }
      else if(this.search.length>0 && !(this.filterDept.length>0))
      {
        //alert("only search")
        return employee.name.toLowerCase().includes(this.search.toLowerCase());
      }
      else if(!(this.search.length>0) && (this.filterDept.length>0 && this.filterDept!="All"))
      {
        //alert("only search")
        return employee.department===this.filterDept;
      }
      else if(this.search.length>0 && this.filterDept==="All")
      {
        //alert("search by dept")
        return employee.name.toLowerCase().includes(this.search.toLowerCase());
      }

      else
      {
        //alert("else")
        return employee;
      }
    });
    //console.log(this.filteredData)
  }
  sendFilteredData()
  {
    this.filterData();
    if(this.filteredData.length==0)
    {
      alert("No employee exist")
    }
    this.filterEvent.emit(this.filteredData);
  }
  clearSearch()
  {
    this.search="";
  }

}

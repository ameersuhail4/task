import { Component, OnInit } from '@angular/core';
import { TaskServiceService } from '../task-service.service';

@Component({
  selector: 'app-task-completed',
  templateUrl: './task-completed.component.html',
  styleUrls: ['./task-completed.component.css']
})
export class TaskCompletedComponent implements OnInit {

  tasks;
  constructor(private taskService:TaskServiceService) { }

  ngOnInit(): void {
    this.taskService.getTasks().subscribe(res=>
      {
        this.tasks=res;
        this.tasks=this.tasks.filter(task=>task.completed==true)
      })
  }

}

import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { TaskServiceService } from '../task-service.service';

@Component({
  selector: 'app-task-summary',
  templateUrl: './task-summary.component.html',
  styleUrls: ['./task-summary.component.css']
})
export class TaskSummaryComponent implements OnInit {


    taskForm:FormGroup;
    add:boolean;
    formData;
  constructor(private taskService:TaskServiceService)
  {}
  ngOnInit()
  {
   
    this.taskForm=new FormGroup(
      {
        'title':new FormControl('',Validators.required),
        'description':new FormControl('',Validators.required),
        'dueDate':new FormControl('',Validators.required),
        'priority':new FormControl('',Validators.required),
        'category':new FormControl('',Validators.required),
        'completed':new FormControl(false)
      }
    )
  }
  submitTask()
  {
    //console.log(this.taskForm.value);
    this.formData=this.taskForm.value;
    this.taskService.addTask(this.formData).subscribe(res=>console.log('res',res));
    this.taskForm.reset();
    this.add=false;
  }
  addTask()
  {
    this.add=true;
    

  }
  onClose()
  {
    this.add=false;
  }
 
  onEditTask(id:number,task)
  {
    // this.taskForm.patchValue(task);
    // this.editFlag=true;
    // this.editId=id;
    // this.add=true;

  }

}

import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class TaskServiceService {
  url='http://localhost:3000/tasks'
  constructor(private http:HttpClient) { }

  addTask(data)
  {
    return this.http.post(this.url,data);
  }
  getTasks()
  {
    return this.http.get(this.url);
  }
  deleteTask(id)
  {
    return this.http.put(this.url+'/'+id,null);
  }
  updateTask(id,data)
  {
    return this.http.patch(this.url+'/'+id,data)
  }
}

import { Component, OnInit } from '@angular/core';
import { TaskServiceService } from '../task-service.service';

@Component({
  selector: 'app-task-pending',
  templateUrl: './task-pending.component.html',
  styleUrls: ['./task-pending.component.css']
})
export class TaskPendingComponent implements OnInit {

  tasks;
  constructor(private taskService:TaskServiceService) { }

  ngOnInit(): void {
    this.taskService.getTasks().subscribe( res=>
      {
        this.tasks=res;
        this.tasks=this.tasks.filter(task=>task.completed==false)
      })
  }


}

import { Component, OnInit } from '@angular/core';
import { TaskServiceService } from '../task-service.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-task-list',
  templateUrl: './task-list.component.html',
  styleUrls: ['./task-list.component.css']
})
export class TaskListComponent implements OnInit {

  tasks;
  isEdit;
  taskForm:FormGroup;
  task;
  constructor(private taskService:TaskServiceService) { }

  ngOnInit(): void {
    this.taskForm=new FormGroup(
      {
        'title':new FormControl('',Validators.required),
        'description':new FormControl('',Validators.required),
        'dueDate':new FormControl('',Validators.required),
        'priority':new FormControl('',Validators.required),
        'category':new FormControl('',Validators.required),
        'completed':new FormControl(false)
      }
    )
    this.taskService.getTasks().subscribe(res=>
      {
        this.tasks=res;
        this.tasks=this.tasks.filter(task=>task.title!=null)
      })
  }
  onDeleteTask(id)
  {
    this.taskService.deleteTask(id).subscribe(res=>console.log(res))
    this.ngOnInit()
  }
  onEditTask(task)
  {
    this.task=task
    this.isEdit=true;
    this.taskForm.patchValue({
      title:task.title,
      description:task.description,
      dueDate:task.dueDate,
      priority:task.priority,
      category:task.category,
      completed:task.completed
    })
   

  }
  submitTask()
  {
    this.taskService.updateTask(this.task.id,this.taskForm.value).subscribe(res=>console.log(res)
      
    );
    this.taskForm.reset()
    this.isEdit=false
    this.ngOnInit()
  }
  onClose()
  {
    this.isEdit=false
  }

}

import { DatePipe } from '@angular/common';
import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'custom'
})
export class CustomPipe implements PipeTransform {

  transform(value:any): any {
    const datePipe=new DatePipe('en-US');
    return datePipe.transform(value,'MM/dd/yyyy');
  }

}

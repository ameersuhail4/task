import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'capitaliza'
})
export class CapitalizaPipe implements PipeTransform {

  transform(value: any): any {
    if(!value)
    {
      return "";
    }
    return value.charAt(0).toUpperCase()+value.slice(1).toLowerCase();
  }

}

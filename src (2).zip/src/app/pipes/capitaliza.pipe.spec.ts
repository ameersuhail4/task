import { CapitalizaPipe } from './capitaliza.pipe';

describe('CapitalizaPipe', () => {
  it('create an instance', () => {
    const pipe = new CapitalizaPipe();
    expect(pipe).toBeTruthy();
  });
});

import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TaskSummaryComponent } from './task-summary/task-summary.component';
import { TaskCompletedComponent } from './task-completed/task-completed.component';
import { TaskPendingComponent } from './task-pending/task-pending.component';
import { TaskListComponent } from './task-list/task-list.component';
import {HttpClientModule} from '@angular/common/http'
import {ReactiveFormsModule} from '@angular/forms'
@NgModule({
  declarations: [
    AppComponent,
    TaskSummaryComponent,
    TaskCompletedComponent,
    TaskPendingComponent,
    TaskListComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

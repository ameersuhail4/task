export interface Task {
}

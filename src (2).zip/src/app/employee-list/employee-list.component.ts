import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {
  modifiedData:any[];
  flag:boolean=false;
  selectedEmp=null;
  selected:boolean=false;
  Employees =[
    {
    "userId":"rirani",
    "department":"IT",
    "name":"Romin Irani",
    "hireDate":"2007-01-10",
    "employeeCode":"E1",
    "address":{
      "city":"bangalore" ,
      "state":"karnataka"
    },
    "phoneNumber":"408-1234567",
    "emailAddress":"romin.k.irani@gmail.com"
    },
    {
    "userId":"nirani",
    "department":"IT",
    "name":"Neil Irani",
    "hireDate":"2002-08-20",
    "employeeCode":"E2",
    "address":
    {
      "city":"koyembedu" ,
      "state":"Tamilnadu"
    },
    "phoneNumber":"408-1111111",
    "emailAddress":"neilrirani@gmail.com"
    },
    {
    "userId":"thanks",
    "department":"HR",
    "name":"Tom Hanks",
    "hireDate":"2012-09-22",
    "employeeCode":"E3",
    "address":
    {
      "city":"Sangareddy" ,
      "state":"telangana"
    },
    "phoneNumber":"408-2222222",
    "emailAddress":"tomhanks@gmail.com"
    }
    ]
   
  constructor() { }

  ngOnInit(): void {
  }
  FilteredData(event: any[])
  {
    this.modifiedData=event;
    this.flag=true;
  }
  selectEmployee(employee: any)
  {
    //console.log(typeof(employee))
    this.selectedEmp=employee;
    this.selected=true;
    
  }
}

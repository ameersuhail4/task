import { Directive, ElementRef, HostListener, OnInit, Renderer2 } from '@angular/core';

@Directive({
  selector: '[appCustom]'
})
export class CustomDirective implements OnInit {

  constructor(private element:ElementRef,private renderer:Renderer2) { }
  ngOnInit(): void {
    
  }
  @HostListener('click') onClick()
  {
    this.renderer.setStyle(this.element.nativeElement,'background-color','lightgreen');
    setTimeout(()=>
    {
      this.renderer.removeStyle(this.element.nativeElement,'background-color');
      
    },2000);
  }

}

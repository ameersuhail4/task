
import { Directive, ElementRef, HostListener, Renderer2 } from '@angular/core';

@Directive({
  selector: '[appAddress]'
})
export class AddressDirective {
  tooltip:any;
  constructor(private element:ElementRef,private renderer:Renderer2) { }
  @HostListener('mouseover') onMouseOver(){
    this.tooltip=this.renderer.createElement('div');
    const address=this.element.nativeElement.innerText;
    this.renderer.appendChild(this.tooltip,this.renderer.createText(address));
    this.renderer.addClass(this.tooltip,'tooltip');
    console.log(this.element.nativeElement)
    this.renderer.appendChild(this.element.nativeElement,this.tooltip);
    //this.renderer.setStyle(this.element.nativeElement,'background-color','lightgreen')
  }
  @HostListener('mouseout') onMouseOut()  
  {
   
    if(this.tooltip)
    {
      this.renderer.removeChild(this.element.nativeElement,this.tooltip);
    }
  }
}

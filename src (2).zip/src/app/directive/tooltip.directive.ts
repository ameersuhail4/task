import { Directive, ElementRef, HostListener, Input, Renderer2 } from '@angular/core';

@Directive({
  selector: '[appTooltip]'
})
export class TooltipDirective {
  @Input('appTooltip') tooltipText:string;
  private tooltipElement:HTMLElement;
  constructor(private element:ElementRef,private renderer:Renderer2) { }
  @HostListener('mouseenter') onMouseOver()
  {
    this.tooltipElement=this.renderer.createElement('div');
    this.tooltipElement.textContent=this.tooltipText;
    this.tooltipElement.className='tooltip';
    this.renderer.appendChild(this.element.nativeElement,this.tooltipElement);
    console.log(this.tooltipElement);
  }
  @HostListener('mouseleave') onMouseOut()
  {
    if(this.tooltipElement)
    {
      this.renderer.removeChild(this.element.nativeElement,this.tooltipElement);
    }
  }
}
